# GDELT measurement methodology — draft

## Metric under test

The experiment uses DOC 2.0 `timelinevolraw`. Each time bucket contains a count of distinct matching articles (`value`) and the total number of monitored articles (`norm`). The share `value / norm` is a candidate for reducing distortions caused by different overall news volume on different days.

This is a measure of monitored news coverage, not public opinion.

## Category caveats

- People: exact full-name searches reduce, but do not eliminate, false matches.
- Events: recurring names may mix multiple editions; the catalogue must define what one instrument represents.
- Countries: names can appear in unrelated contexts.
- Cities: homonyms require geographic identity metadata and aliases.
- Polish cities: compare accented and unaccented spellings.
- People popular in Polish media: `sourcecountry:poland` is a publisher-location proxy, not a nationality or story-location filter.

## Candidate discovery

The initial list is manually curated for measurement tests. A separate GKG-based experiment is required to evaluate automatic entity/theme discovery, alias consolidation and disambiguation.

## Pricing

No TR pricing formula is defined here. First validate query quality and preserve daily observations. Only then define a per-instrument normalized index.
