import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";

const API = "https://api.gdeltproject.org/api/v2/doc/doc";
const timespan = process.env.GDELT_TIMESPAN || "30d";
const today = new Date().toISOString().slice(0, 10);

const candidates = [
  { id: "person_trump", category: "world_people", label: "Donald Trump", query: '"Donald Trump"', scope: "global" },
  { id: "person_taylor_swift", category: "world_people", label: "Taylor Swift", query: '"Taylor Swift"', scope: "global" },
  { id: "event_olympic_games", category: "world_events", label: "Olympic Games", query: '"Olympic Games"', scope: "global" },
  { id: "event_un_general_assembly", category: "world_events", label: "United Nations General Assembly", query: '"United Nations General Assembly"', scope: "global" },
  { id: "country_france", category: "world_countries", label: "France", query: "France", scope: "global" },
  { id: "country_japan", category: "world_countries", label: "Japan", query: "Japan", scope: "global" },
  { id: "city_paris", category: "world_cities", label: "Paris", query: "Paris", scope: "global" },
  { id: "city_tokyo", category: "world_cities", label: "Tokyo", query: "Tokyo", scope: "global" },
  { id: "pl_city_gdansk", category: "polish_cities", label: "Gdańsk", query: "Gdańsk", scope: "global" },
  { id: "pl_city_krakow", category: "polish_cities", label: "Kraków", query: "Kraków", scope: "global" },
  { id: "pl_person_tusk", category: "polish_media_people", label: "Donald Tusk", query: '"Donald Tusk" sourcecountry:poland', scope: "polish_sources" },
  { id: "pl_person_lewandowski", category: "polish_media_people", label: "Robert Lewandowski", query: '"Robert Lewandowski" sourcecountry:poland', scope: "polish_sources" }
];

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function fetchTimeline(candidate) {
  const params = new URLSearchParams({
    query: candidate.query,
    mode: "timelinevolraw",
    format: "json",
    timespan
  });
  const url = `${API}?${params.toString()}`;

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const response = await fetch(url, {
        headers: { "User-Agent": "Trendsy-GDELT-PoC/0.1" }
      });
      const body = await response.text();
      if (!response.ok) throw new Error(`HTTP ${response.status}: ${body.slice(0, 300)}`);

      let parsed;
      try { parsed = JSON.parse(body); }
      catch { throw new Error(`Non-JSON response: ${body.slice(0, 300)}`); }

      const series = parsed.timeline?.[0];
      if (!series || !Array.isArray(series.data)) {
        throw new Error(`Unexpected response shape: ${JSON.stringify(parsed).slice(0, 500)}`);
      }

      return {
        candidate, requestedAt: new Date().toISOString(), timespan, url,
        points: series.data.map((p) => ({
          date: p.date,
          matchingArticles: Number(p.value),
          totalArticlesNorm: p.norm == null ? null : Number(p.norm)
        }))
      };
    } catch (error) {
      if (attempt === 3) return { candidate, requestedAt: new Date().toISOString(), timespan, error: String(error) };
      await sleep(attempt * 1800);
    }
  }
}

const results = [];
for (const candidate of candidates) {
  console.log(`Testing ${candidate.label} [${candidate.category}]...`);
  results.push(await fetchTimeline(candidate));
  await sleep(1200);
}

await mkdir("output", { recursive: true });
const jsonPath = join("output", `gdelt-raw-${today}.json`);
const csvPath = join("output", `gdelt-summary-${today}.csv`);

await writeFile(jsonPath, JSON.stringify({
  source: "GDELT DOC 2.0", api: API, generatedAt: new Date().toISOString(), timespan, results
}, null, 2));

const csv = ["id,category,label,scope,date,matching_articles,total_articles_norm,error"];
for (const r of results) {
  const c = r.candidate;
  if (r.error) {
    csv.push([c.id,c.category,JSON.stringify(c.label),c.scope,"","","",JSON.stringify(r.error)].join(","));
    continue;
  }
  for (const p of r.points) {
    csv.push([c.id,c.category,JSON.stringify(c.label),c.scope,p.date,p.matchingArticles,p.totalArticlesNorm ?? "",""].join(","));
  }
}
await writeFile(csvPath, csv.join("\n") + "\n");

console.table(results.map((r) => ({
  id: r.candidate.id,
  category: r.candidate.category,
  points: r.points?.length ?? 0,
  totalMatches: r.points?.reduce((s,p) => s + p.matchingArticles, 0) ?? null,
  error: r.error ?? ""
})));
console.log(`Saved ${jsonPath} and ${csvPath}`);
if (results.some((r) => r.error)) process.exitCode = 1;
