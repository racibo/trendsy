# Trendsy — GDELT proof of concept

This is the first technical experiment, not the game itself. It tests whether GDELT DOC 2.0 can provide stable daily news-coverage series for representative candidate instruments.

## Run

Requires Node.js 20+ and internet access. No API key is required.

```bash
node scripts/gdelt-smoke-test.mjs
```

Optional lookback window:

```bash
GDELT_TIMESPAN=30d node scripts/gdelt-smoke-test.mjs
```

Results are written to `output/` as JSON and CSV.

## What is being tested

- `timelinevolraw`: daily counts of distinct matching articles and GDELT's `norm` denominator.
- Global searches versus searches restricted to Polish publishing sources.
- Missing dates, zero counts, API errors, and response shape.
- A small seed list spanning all six proposed game categories.

The seed list is manually curated. It does not prove automatic discovery of 30 good instruments per category.

## Important limitations

1. GDELT measures monitored news coverage, not public opinion, readership, searches, or the number of interested people.
2. `sourcecountry:poland` filters the publisher's country. It does not mean the story is about Poland and does not identify the subject's nationality.
3. DOC 2.0 has a rolling window of approximately three months. Trendsy must store daily snapshots itself for longer price histories.
4. Common city/country names can produce false matches. Entity identity, aliases and homonym resolution need a separate stage.
5. Raw counts are not directly comparable across instruments. Do not convert them directly into TR.

## Source attribution

Data source: [GDELT Project](https://www.gdeltproject.org/).
API documentation: [GDELT DOC 2.0](https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/).

The public Trendsy application must visibly attribute and link to GDELT.
